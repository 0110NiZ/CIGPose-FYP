"""CIGPose intervention strength module."""
