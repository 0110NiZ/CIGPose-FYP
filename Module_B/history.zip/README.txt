Original source bytes used for the completed experiments.
Not active entry points. Original report hashes must not be edited.
smoke_b_labels.py remains in repository commit f758e60.
