"""Train a B-only four-gain regressor from verified full_train_v4 labels.

Only source-cache features/uncertainty/confidence/joint identity enter B.
GT/gains are supervision and evaluation only. No val2017 data is read.
Development groups are images within train2017, not a replacement COCO split.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import sys

os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import numpy as np

ALPHAS = [.25, .5, .75, 1.]
FEATURE_SPEC = dict(
    name='b_source_features_v1', dimension=563,
    fields=['selected_joint_feature[256]', 'mean_joint_feature[256]',
            'uncertainty[17]', 'confidence[17]', 'selected_joint_one_hot[17]'],
    excludes=['GT', 'gain', 'candidate_predictions', 'oracle_alpha'],
)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def image_number(image_id, seed, purpose):
    return int.from_bytes(hashlib.sha256(
        f'b-train-v1:{seed}:{purpose}:{int(image_id)}'.encode()).digest()[:8], 'big')


def is_development(image_id, seed):
    return image_number(image_id, seed, 'split') < (1 << 64)//10


def select_ids(expected, seed, max_instances):
    """A smoke limit retains whole images; selection and split use distinct salts."""
    groups = {}
    for ann_id, image_id in expected.items():
        groups.setdefault(image_id, []).append(ann_id)
    if max_instances is None:
        return set(expected)
    selected = set()
    for image_id in sorted(groups, key=lambda v: (image_number(v, seed, 'smoke'), v)):
        selected.update(groups[image_id])
        if len(selected) >= max_instances:
            break
    return selected


def make_features(arrays):
    """Shared inference input builder: this function never reads labels or GT."""
    f = arrays['features']
    joint = arrays['top1_joint']
    n = len(joint)
    if f.shape != (n, 17, 256) or not np.issubdtype(joint.dtype, np.integer):
        raise ValueError('Bad feature/joint schema')
    if np.any((joint < 0) | (joint >= 17)):
        raise ValueError('Joint index out of range')
    x = np.concatenate([
        f[np.arange(n), joint], f.mean(axis=1), arrays['uncertainty'],
        arrays['confidence'], np.eye(17, dtype=np.float32)[joint],
    ], axis=1).astype(np.float32)
    if x.shape != (n, FEATURE_SPEC['dimension']) or not np.isfinite(x).all():
        raise ValueError('Invalid B input')
    return x


def prepare_data(cache, label_dir, seed, max_instances):
    run = json.loads((label_dir/'run.json').read_text())
    summary = json.loads((label_dir/'summary.json').read_text())
    if (run.get('schema_version') != 'b-only-labels-v4' or run.get('scope') != 'full'
            or summary.get('scope') != 'full' or summary.get('passed') is not True
            or summary.get('fingerprint') != digest(run)
            or run.get('alphas') != ALPHAS
            or summary.get('instances') != 149813
            or summary.get('candidate_records') != 599252
            or run.get('source_cache_run_sha256') != sha(cache.directory/'run.json')
            or cache.run['protocol'].get('dataset_split') != 'train2017'):
        raise ValueError('Require the complete verified v4 train2017 label run and its source cache')
    infos = run['source_shards']
    ids = [int(i) for info in infos for i in info['annotation_ids']]
    if len(ids) != len(set(ids)) or set(ids) != set(cache.expected) or len(ids) != 149813:
        raise ValueError('Label manifest does not exactly cover train cache IDs')
    selected = select_ids(cache.expected, seed, max_instances)
    n = len(selected)
    x = np.empty((n, FEATURE_SPEC['dimension']), np.float32)
    gains = np.empty((n, 4), np.float64)
    ann_ids = np.empty(n, np.int64)
    image_ids = np.empty(n, np.int64)
    seen = set()
    offset = 0
    used_files = []
    fingerprint = digest(run)
    for seq, info in enumerate(infos, 1):
        if not selected.intersection(info['annotation_ids']):
            continue
        source = cache.directory/info['name']
        if Path(info['name']).name != info['name'] or sha(source) != info['sha256']:
            raise ValueError('Source shard hash/name mismatch')
        a = cache.load_shard(source)
        np.testing.assert_array_equal(a['annotation_id'], info['annotation_ids'])
        stem = source.stem
        report_path, payload = label_dir/(stem+'.json'), label_dir/(stem+'.npz')
        rep = json.loads(report_path.read_text())
        if (rep['fingerprint'] != fingerprint or rep['source'] != info
                or sha(payload) != rep['result_sha256']
                or not rep['source_arrays_unchanged']
                or not rep['alpha1_full_replacement_features_equal']):
            raise ValueError('Label shard provenance/hash/check mismatch: '+stem)
        with np.load(payload, allow_pickle=False) as labels:
            np.testing.assert_array_equal(labels['annotation_id'], a['annotation_id'])
            np.testing.assert_array_equal(labels['image_id'], a['image_id'])
            np.testing.assert_array_equal(labels['joint_id'], a['top1_joint'])
            np.testing.assert_array_equal(labels['alphas'], np.asarray(ALPHAS, np.float32))
            g = labels['gain'].copy()
            if g.shape != (len(a['annotation_id']), 4) or not np.isfinite(g).all():
                raise ValueError('Bad gain supervision')
            np.testing.assert_allclose(g, labels['oks_after']-labels['oks_before'][:, None],
                                       atol=1e-12, rtol=0)
        mask = np.asarray([int(v) in selected for v in a['annotation_id']])
        joined = set(map(int, a['annotation_id'][mask]))
        if seen & joined:
            raise ValueError('Duplicate training IDs')
        seen.update(joined)
        end = offset + int(mask.sum())
        x[offset:end] = make_features(a)[mask]
        gains[offset:end] = g[mask]
        ann_ids[offset:end], image_ids[offset:end] = a['annotation_id'][mask], a['image_id'][mask]
        offset = end
        used_files.append(dict(source=info['name'], source_sha256=info['sha256'],
            labels_sha256=rep['result_sha256'], report_sha256=sha(report_path)))
        if len(used_files) % 128 == 0:
            print(f'Loaded verified training rows: {offset}/{n}', flush=True)
    if seen != selected or offset != n:
        raise ValueError('Incomplete training join')
    dev = np.asarray([is_development(v, seed) for v in image_ids])
    if not dev.any() or dev.all():
        raise ValueError('Empty train or development partition; increase smoke sample')
    if set(image_ids[dev]) & set(image_ids[~dev]):
        raise ValueError('Image leakage across train/development')
    print(f'Data ready: {n} people; train={(~dev).sum()}, development={dev.sum()}', flush=True)
    return x, gains, ann_ids, image_ids, dev, used_files, run, summary


def normalization(x, train_mask):
    mean = x[train_mask].mean(axis=0, dtype=np.float64).astype(np.float32)
    std = x[train_mask].std(axis=0, dtype=np.float64).astype(np.float32)
    std[std < 1e-6] = 1.
    return mean, std


def gain_metrics(predicted, actual, fixed_from_train):
    if predicted.shape != actual.shape or not np.isfinite(predicted).all():
        raise ValueError('Invalid B prediction')
    choice = predicted.argmax(axis=1)  # Exact predicted ties: smallest alpha.
    chosen = actual[np.arange(len(choice)), choice]
    best = actual.max(axis=1)
    return dict(selected_mean_gain=float(chosen.mean()),
        oracle_mean_gain=float(best.mean()), mean_oracle_regret=float((best-chosen).mean()),
        mean_gain_vs_fixed_from_train=float(chosen.mean()-actual[:, fixed_from_train].mean()),
        fixed_from_train_alpha=ALPHAS[fixed_from_train],
        fixed_alpha_mean_gains={str(v):float(actual[:,j].mean()) for j,v in enumerate(ALPHAS)},
        selected_alpha_counts={str(v):int((choice==j).sum()) for j,v in enumerate(ALPHAS)},
        selected_negative_people=int((chosen<0).sum()),
        all_candidate_negative_people=int((best<0).sum()),
        exact_best_tie_people=int(((actual==best[:,None]).sum(axis=1)>1).sum()))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'cache', 'labels', 'output'):
        p.add_argument('--'+name, type=Path, required=True)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--smoke', action='store_true')
    mode.add_argument('--full', action='store_true')
    p.add_argument('--epochs', type=int)
    p.add_argument('--batch-size', type=int, default=512)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--resume', action='store_true')
    args = p.parse_args()
    args.epochs = args.epochs if args.epochs is not None else (3 if args.smoke else 30)
    if args.epochs <= 0 or args.batch_size <= 0:
        p.error('Epochs and batch size must be positive')
    for name in ('repo', 'cache', 'labels', 'output'):
        setattr(args, name, getattr(args, name).resolve())
    for protected in (args.cache, args.labels):
        if args.output == protected or protected in args.output.parents or args.output in protected.parents:
            raise ValueError('Training output must be separate from labels and source cache')
    sys.path.insert(0, str(args.repo/'mmpose/analysis/fyp'))
    from shared_cache import ReferenceCache
    cache = ReferenceCache(args.cache)
    x, g, ann_ids, image_ids, dev, files, labels_run, labels_summary = prepare_data(
        cache, args.labels, args.seed, 4096 if args.smoke else None)
    mean, std = normalization(x, ~dev)
    split = dict(schema_version='b_image_development_v1', dataset_split='train2017',
        purpose='B internal development only; official val2017 is untouched', seed=args.seed,
        rule='sha256(b-train-v1:seed:split:image_id) first 64 bits < floor(2**64/10)',
        development_fraction_target=.1, smoke=bool(args.smoke),
        train_annotation_ids=ann_ids[~dev].tolist(), development_annotation_ids=ann_ids[dev].tolist(),
        train_image_ids=sorted(set(map(int,image_ids[~dev]))),
        development_image_ids=sorted(set(map(int,image_ids[dev]))))
    import torch
    if args.device.startswith('cuda') and not torch.cuda.is_available():
        raise RuntimeError('CUDA requested but unavailable')
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    nn = torch.nn
    model = nn.Sequential(nn.Linear(563,128), nn.ReLU(), nn.Dropout(.1),
                          nn.Linear(128,64), nn.ReLU(), nn.Linear(64,4)).to(args.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    scale = 1000.
    run = dict(schema_version='b-gain-regressor-v1', scope='smoke' if args.smoke else 'full',
        script_sha256=sha(__file__), source_cache_run_sha256=sha(args.cache/'run.json'),
        labels_fingerprint=digest(labels_run), labels_summary_sha256=sha(args.labels/'summary.json'),
        label_files_digest=digest(files), split_sha256=digest(split), feature_spec=FEATURE_SPEC,
        network='563-128-ReLU-Dropout(0.1)-64-ReLU-4', alphas=ALPHAS,
        loss='SmoothL1(beta=1) on each of four gains multiplied by 1000; retain ties',
        gain_scale=scale, optimizer=dict(type='AdamW',lr=1e-3,weight_decay=1e-4),
        model_selection='maximum mean selected gain on image-disjoint train2017 development',
        epochs=args.epochs,batch_size=args.batch_size,seed=args.seed,
        device=args.device,torch_version=torch.__version__,numpy_version=np.__version__,
        python=sys.version, CUBLAS_WORKSPACE_CONFIG=os.environ['CUBLAS_WORKSPACE_CONFIG'],
        frozen_cigpose=True, ground_truth_in_inputs=False, val2017_used=False,
        limitations=['Smoke results only validate training flow.',
            'Development OKS gains are not formal COCO AP/AR.',
            'B selects only positive intervention strengths; no reject action.',
            'Official COCO evaluation requires matching current-runtime P0/Top-1 controls.'])
    if args.output.exists():
        if not args.resume:
            raise FileExistsError('Output exists; use a new directory or identical --resume run')
        if json.loads((args.output/'run.json').read_text()) != run:
            raise ValueError('Resume inputs/code/settings differ')
    else:
        if args.resume:
            raise FileNotFoundError('Cannot resume nonexistent output')
        args.output.mkdir(parents=True)
        atomic_json(args.output/'run.json',run)
        atomic_json(args.output/'split.json',split)
    lock = args.output/'.writer.lock'
    with lock.open('x') as f:
        f.write(str(os.getpid()))
    try:
        # Statistics fitted to training rows only; B sees no target-dependent inputs.
        x -= mean
        x /= std
        if not np.isfinite(x).all():
            raise ValueError('Non-finite standardized feature')
        train_x = torch.from_numpy(x[~dev].copy())
        train_y = torch.from_numpy((g[~dev]*scale).astype(np.float32))
        dev_x = torch.from_numpy(x[dev].copy())
        dev_gain = g[dev]
        fixed = int(g[~dev].mean(axis=0).argmax())
        del x
        generator = torch.Generator().manual_seed(args.seed)
        loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_x,train_y),
            batch_size=args.batch_size, shuffle=True, num_workers=0, generator=generator)
        def evaluate():
            model.eval()
            predictions=[]
            with torch.inference_mode():
                for start in range(0,len(dev_x),1024):
                    predictions.append(model(dev_x[start:start+1024].to(args.device)).cpu().numpy()/scale)
            return gain_metrics(np.concatenate(predictions), dev_gain, fixed)
        def checkpoint(epoch,best_gain,best_epoch):
            return dict(model=model.state_dict(),optimizer=optimizer.state_dict(),epoch=epoch,
                best_gain=best_gain,best_epoch=best_epoch,normalization_mean=torch.from_numpy(mean),
                normalization_std=torch.from_numpy(std),feature_spec=FEATURE_SPEC,alphas=ALPHAS,
                gain_scale=scale,run_fingerprint=digest(run),generator_state=generator.get_state(),
                rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [])
        def save_checkpoint(name,payload):
            tmp=args.output/(name+'.tmp')
            torch.save(payload,tmp)
            os.replace(tmp,args.output/name)
        start,best_gain,best_epoch=0,-float('inf'),0
        history=[]
        if args.resume:
            state=torch.load(args.output/'last.pt',map_location='cpu',weights_only=True)
            if state['run_fingerprint']!=digest(run):
                raise ValueError('Checkpoint identity mismatch')
            model.load_state_dict(state['model']);optimizer.load_state_dict(state['optimizer'])
            generator.set_state(state['generator_state']);torch.set_rng_state(state['rng_state'])
            if torch.cuda.is_available():
                torch.cuda.set_rng_state_all(state['cuda_rng_state'])
            start,best_gain,best_epoch=state['epoch'],state['best_gain'],state['best_epoch']
            if (args.output/'history.json').exists():
                history=json.loads((args.output/'history.json').read_text())[:start]
        for epoch in range(start+1,args.epochs+1):
            model.train();total=0.;rows=0
            for bx,by in loader:
                bx,by=bx.to(args.device),by.to(args.device)
                optimizer.zero_grad(set_to_none=True)
                loss=nn.functional.smooth_l1_loss(model(bx),by)
                if not torch.isfinite(loss):
                    raise ValueError('Non-finite training loss')
                loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5.);optimizer.step()
                total+=float(loss.detach())*len(bx);rows+=len(bx)
            metrics=evaluate()
            record=dict(epoch=epoch,train_scaled_huber_loss=total/rows,development=metrics)
            history.append(record)
            if metrics['selected_mean_gain']>best_gain:
                best_gain=metrics['selected_mean_gain'];best_epoch=epoch
                save_checkpoint('best.pt',checkpoint(epoch,best_gain,best_epoch))
            atomic_json(args.output/'history.json',history)
            save_checkpoint('last.pt',checkpoint(epoch,best_gain,best_epoch))
            print(f"Epoch {epoch}/{args.epochs}: loss={total/rows:.6f}, "
                  f"dev gain={metrics['selected_mean_gain']:+.8f}, "
                  f"vs train-fixed={metrics['mean_gain_vs_fixed_from_train']:+.8f}",flush=True)
        state=torch.load(args.output/'best.pt',map_location='cpu',weights_only=True)
        model.load_state_dict(state['model'])
        metrics=evaluate()
        result=dict(training_completed=True,scope=run['scope'],flow_check_only=bool(args.smoke),
            run_fingerprint=digest(run),instances=len(ann_ids),train_people=int((~dev).sum()),
            development_people=int(dev.sum()),images_disjoint=True,gt_in_inputs=False,
            val2017_used=False,best_epoch=best_epoch,best_checkpoint_sha256=sha(args.output/'best.pt'),
            development=metrics,beats_train_selected_fixed=metrics['mean_gain_vs_fixed_from_train']>0,
            formal_coco_ap_evaluated=False)
        atomic_json(args.output/'summary.json',result)
        print(json.dumps(result,indent=2),flush=True)
    finally:
        lock.unlink()


if __name__=='__main__':
    main()
