import torch
import torch.nn.functional as F
from torch import nn, Tensor
import numpy as np
from typing import Optional, Sequence, Tuple, Union
from mmengine.dist import get_dist_info
from mmengine.hooks import Hook
from mmengine.structures import PixelData
from mmpose.models.utils.rtmcc_block import RTMCCBlock, ScaleNorm
import warnings
import csv
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
import random

from mmpose.codecs.utils import get_simcc_normalized
from mmpose.evaluation.functional import simcc_pck_accuracy
from mmpose.models.utils.hierarchical_gnn import HGNNModule
from mmpose.models.utils.tta import flip_vectors
from mmpose.registry import MODELS, HOOKS
from mmpose.evaluation.functional import keypoint_pck_accuracy
from mmpose.utils.tensor_utils import to_numpy
from mmpose.utils.typing import (ConfigType, InstanceList, OptConfigType,
                                 OptSampleList)
from .rtmcc_head import RTMCCHead

@MODELS.register_module()
class CausalInterventionModule(nn.Module):
    """CIM with original confidence selection or learned deterministic Top-1.

    Learned selection is controlled by use_neighbor/use_global (2 x 2 ablation).
    The forward pass *exactly* replaces one selected keypoint with its learned
    canonical embedding; a straight-through surrogate supplies score gradients.
    No extra reward/gain supervision or change to the HGNN is required.
    """

    def __init__(self,
                 num_keypoints: int,
                 feature_dim: int,
                 intervention_strategy: str = 'topk',
                 intervention_k: int = 10,
                 intervention_k_val: int = 1,
                 intervention_threshold: float = 0.5,
                 selection_mode: str = 'confidence',
                 use_neighbor: bool = False,
                 use_global: bool = False,
                 scorer_hidden_dim: int = 32,
                 selection_tau: float = 1.0,
                 keypoint_connections: Optional[Sequence[Tuple[int, int]]] = None):
        super().__init__()
        if intervention_strategy not in ('topk', 'threshold'):
            raise ValueError("intervention_strategy must be 'topk' or 'threshold'")
        if selection_mode not in ('confidence', 'learnable'):
            raise ValueError("selection_mode must be 'confidence' or 'learnable'")
        if selection_tau <= 0:
            raise ValueError('selection_tau must be positive')

        self.num_keypoints = num_keypoints
        self.feature_dim = feature_dim
        self.intervention_strategy = intervention_strategy
        self.intervention_k = intervention_k
        self.intervention_k_val = intervention_k_val
        self.intervention_threshold = intervention_threshold
        self.selection_mode = selection_mode
        self.use_neighbor = use_neighbor
        self.use_global = use_global
        self.selection_tau = selection_tau
        self.canonical_features = nn.Embedding(num_keypoints, feature_dim)
        self.last_selected_indices = None  # diagnostic only; do not save in state_dict
        # Diagnostic state is deliberately NOT a buffer: EMA swaps all buffers.
        self.eval_selection_counts = torch.zeros(num_keypoints, dtype=torch.long)
        self.eval_count_flip_indices = None  # diagnostic mapping only, not a model input

        if selection_mode == 'learnable':
            # Exactly the same scorer shape/parameter count for variants A/B/C/D.
            # 3*C -> 32 -> 1, with SiLU, no norm, dropout or extra confidence.
            self.scorer = nn.Sequential(
                nn.Linear(feature_dim * 3, scorer_hidden_dim),
                nn.SiLU(),
                nn.Linear(scorer_hidden_dim, 1),
            )
            # Row i contains weights for the direct undirected neighbors of i.
            # Self edges ignored; duplicate and reversed edges deduplicated.
            neighbors = [set() for _ in range(num_keypoints)]
            for src, dst in (keypoint_connections or []):
                if not (0 <= src < num_keypoints and 0 <= dst < num_keypoints):
                    raise ValueError('Keypoint connection index out of range')
                if src != dst:
                    neighbors[src].add(dst)
                    neighbors[dst].add(src)
            matrix = torch.zeros(num_keypoints, num_keypoints)
            for i, connected in enumerate(neighbors):
                if connected:
                    matrix[i, list(sorted(connected))] = 1.0 / len(connected)
            self.register_buffer('neighbor_aggregation', matrix, persistent=False)
        else:
            # Legacy confidence CIM retains its exact original parameter count.
            self.scorer = None

    def _record_selection(self, mask):
        # Always report anatomical joint IDs in the original-image frame.
        ids = mask.nonzero(as_tuple=False)[:, 1].detach().cpu()
        if self.eval_count_flip_indices is not None:
            ids = torch.as_tensor(self.eval_count_flip_indices, dtype=torch.long)[ids]
        self.eval_selection_counts.add_(torch.bincount(ids, minlength=self.num_keypoints))

    def _learnable_scores(self, f_kpts: Tensor) -> Tensor:
        """Score each of K joints, with shape [B, K]."""
        batch_size, num_keypoints, channels = f_kpts.shape
        if num_keypoints != self.num_keypoints or channels != self.feature_dim:
            raise ValueError('CIM expects features [B, %d, %d]' % (
                self.num_keypoints, self.feature_dim))
        neighbor = (torch.matmul(self.neighbor_aggregation.to(f_kpts.dtype),
                                 f_kpts) if self.use_neighbor
                    else torch.zeros_like(f_kpts))
        global_context = (f_kpts.mean(dim=1, keepdim=True).expand(
            batch_size, num_keypoints, -1)
                          if self.use_global else torch.zeros_like(f_kpts))
        score_inputs = torch.cat((f_kpts, neighbor, global_context), dim=-1)
        return self.scorer(score_inputs).squeeze(-1)

    def forward(self, f_kpts: Tensor,
                h_initial: Tuple[Tensor, Tensor]) -> Tuple[Tensor, Tensor]:
        """Return (intervened_features [B,K,C], bool_intervention_mask [B,K])."""
        if self.selection_mode == 'learnable':
            scores = self._learnable_scores(f_kpts)
            selected = scores.argmax(dim=-1)  # deterministic top-1 in train AND eval
            hard_mask = F.one_hot(selected, num_classes=self.num_keypoints).bool()
            self.last_selected_indices = selected.detach()
            if not self.training:
                with torch.no_grad():
                    self._record_selection(hard_mask)

            # Use torch.where for the *actual* hard full replacement. This keeps
            # gradients to feature and canonical tensors identical to hard Top-1.
            canonical = self.canonical_features.weight.to(f_kpts.dtype)
            hard_features = torch.where(
                hard_mask.unsqueeze(-1), canonical.unsqueeze(0), f_kpts)

            if self.training:
                # Zero-valued forward bridge. Backward estimates the effect of
                # changing the discrete choice using deterministic softmax.
                # Detached (canonical - features) avoids introducing spurious
                # soft gradients into the backbone/canonical hard path.
                soft = torch.softmax(scores.float() / self.selection_tau, dim=-1)
                bridge = (soft - soft.detach()).to(f_kpts.dtype).unsqueeze(-1)
                bridge = bridge * (canonical.unsqueeze(0) - f_kpts).detach()
                hard_features = hard_features + bridge
            return hard_features, hard_mask

        # -------- Original confidence-based CIM (left unchanged) --------
        h_initial_x, h_initial_y = h_initial
        device = f_kpts.device
        with torch.no_grad():
            conf_x = h_initial_x.softmax(dim=-1).max(dim=-1)[0]
            conf_y = h_initial_y.softmax(dim=-1).max(dim=-1)[0]
            confidence = (conf_x + conf_y) / 2.0
            confound_score = 1.0 - confidence
            intervened_mask = torch.zeros_like(
                confidence, dtype=torch.bool, device=device)
            if self.intervention_strategy == 'topk':
                k = self.intervention_k if self.training else self.intervention_k_val
                if k > 0:
                    k = min(k, self.num_keypoints)
                    _, topk_indices = torch.topk(confound_score, k, dim=1)
                    intervened_mask.scatter_(1, topk_indices, True)
            else:
                intervened_mask = confound_score > self.intervention_threshold

        self.last_selected_indices = intervened_mask.long().argmax(dim=1).detach()
        if not self.training:
            with torch.no_grad():
                self._record_selection(intervened_mask)
        intervened_indices = torch.where(intervened_mask)
        if intervened_indices[0].numel() == 0:
            return f_kpts.clone(), intervened_mask
        kpt_indices_to_lookup = intervened_indices[1]
        canonical_feats = self.canonical_features(kpt_indices_to_lookup)
        f_prime_kpts = f_kpts.clone()
        f_prime_kpts[intervened_indices] = canonical_feats
        return f_prime_kpts, intervened_mask

@MODELS.register_module()
class CIGHead(RTMCCHead):
    def __init__(
        self,
        in_channels,
        out_channels,
        input_size,
        in_featuremap_size,
        in_featuremap_num=4,
        simcc_split_ratio=2.0,
        final_layer_kernel_size=1,
        gau_cfg=dict(),
        loss=dict(),
        loss_cf=dict(),
        decoder=None,
        gcn_cfg=dict(),
        cim_cfg=dict(),
        keypoint_connections=None,
        keypoint_groups=None,
        init_cfg=None,
        **kwargs
    ):
        if init_cfg is None:
            init_cfg = self.default_init_cfg
        super().__init__(
            in_channels,
            out_channels,
            input_size,
            in_featuremap_size,
            simcc_split_ratio,
            final_layer_kernel_size,
            gau_cfg,
            loss,
            decoder,
            init_cfg,
            **kwargs,
        )
        self.loss_cf_module = MODELS.build(loss_cf)

        W = int(self.input_size[0] * self.simcc_split_ratio)
        H = int(self.input_size[1] * self.simcc_split_ratio)

        hidden_dims = gau_cfg['hidden_dims']
        in_mlp = 0
        for i in range(in_featuremap_num):
            in_mlp += 4 ** i
        flatten_dims_GCN = in_mlp * (self.in_featuremap_size[0] * self.in_featuremap_size[1])
        self.mlp_pre_gau = nn.Sequential(
            ScaleNorm(flatten_dims_GCN),
            nn.Linear(flatten_dims_GCN, gau_cfg['hidden_dims'], bias=False))

        self.initial_pred_x = nn.Linear(hidden_dims, W)
        self.initial_pred_y = nn.Linear(hidden_dims, H)

        # Do not mutate the caller's config; pass the same skeleton used by HGNN.
        cim_cfg = dict(cim_cfg)
        cim_cfg.update(num_keypoints=out_channels, feature_dim=hidden_dims)
        cim_cfg.setdefault('keypoint_connections', keypoint_connections)
        self.cim = CausalInterventionModule(**cim_cfg)

        self.gcn = HGNNModule(gcn_cfg, keypoint_connections, keypoint_groups)

        self.cls_gx = nn.Linear(gcn_cfg['hidden_dim'], W)
        self.cls_gy = nn.Linear(gcn_cfg['hidden_dim'], H)
        
    def forward(self, feats: Tuple[Tensor, ...]) -> Tuple[Tensor, Tensor]:
        """Forward pass (for predict). This method executes the complete CI-GNN inference pipeline."""
        # Initial feature processing
        x = self.final_layer(feats[-1]) # B, K, H', W'
        x = torch.flatten(x, 2) # B, K, H'*W'
        
        f_kpts_initial = self.mlp_pre_gau(x) # B, K, hidden_dims
        
        f_kpts = self.gau(f_kpts_initial) # [B, K, C_hidden]

        # 2. Get initial predictions for intervention
        h_initial_x = self.initial_pred_x(f_kpts)
        h_initial_y = self.initial_pred_y(f_kpts)
        
        # 3. Apply causal intervention
        f_prime_kpts, _ = self.cim(f_kpts, (h_initial_x, h_initial_y))
        
        # 4. GCN refinement on intervened features
        gcn_out = self.gcn(f_prime_kpts) # [B, K, C_gcn_hidden]
        
        # 5. Final prediction
        pred_x = self.cls_gx(gcn_out)
        pred_y = self.cls_gy(gcn_out)

        return pred_x, pred_y

    def loss(self,
             feats: Tuple[Tensor],
             batch_data_samples: OptSampleList,
             train_cfg: OptConfigType = {}) -> dict:
        """Calculate losses. This method implements the complete training logic,
        including the counterfactual consistency loss."""
        gt_x = torch.cat([d.gt_instance_labels.keypoint_x_labels for d in batch_data_samples], dim=0)
        gt_y = torch.cat([d.gt_instance_labels.keypoint_y_labels for d in batch_data_samples], dim=0)
        keypoint_weights = torch.cat([d.gt_instance_labels.keypoint_weights for d in batch_data_samples], dim=0)
        gt_simcc = (gt_x, gt_y)
        
        # --- Common feature extraction ---
        x = self.final_layer(feats[-1])
        x = torch.flatten(x, 2)
        f_kpts_initial = self.mlp_pre_gau(x)
        f_kpts = self.gau(f_kpts_initial)

        # --- Counterfactual Path (for the main loss L_kpt) ---
        h_initial_x = self.initial_pred_x(f_kpts.detach()) # Detach gradients from this branch, used only for CIM decision-making
        h_initial_y = self.initial_pred_y(f_kpts.detach())
        f_prime_kpts, intervened_mask = self.cim(f_kpts, (h_initial_x, h_initial_y))
        gcn_out_cf = self.gcn(f_prime_kpts)
        pred_x_cf = self.cls_gx(gcn_out_cf)
        pred_y_cf = self.cls_gy(gcn_out_cf)
        pred_simcc_cf = (pred_x_cf, pred_y_cf)

        # --- Observational Path (for the consistency loss L_cf) ---
        with torch.no_grad():
            gcn_out_obs = self.gcn(f_kpts)
            pred_x_obs = self.cls_gx(gcn_out_obs)
            pred_y_obs = self.cls_gy(gcn_out_obs)
            pred_simcc_obs = (pred_x_obs, pred_y_obs)

        # --- Loss Calculation ---
        losses = dict()
        loss_kpt = self.loss_module(pred_simcc_cf, gt_simcc, keypoint_weights)
        losses['loss_kpt'] = loss_kpt

        loss_cf = self.loss_cf_module(pred_simcc_obs, pred_simcc_cf, intervened_mask, keypoint_weights)
        losses['loss_cf'] = loss_cf
        
        # --- Accuracy Calculation ---
        _, avg_acc, _ = simcc_pck_accuracy(
            output=to_numpy(pred_simcc_cf),
            target=to_numpy(gt_simcc),
            simcc_split_ratio=self.simcc_split_ratio,
            mask=to_numpy(keypoint_weights) > 0)
        acc_pose = torch.tensor(avg_acc, device=gt_x.device)
        losses['acc_pose'] = acc_pose

        return losses
    
    def predict(
        self,
        feats: Tuple[Tensor],
        batch_data_samples: OptSampleList,
        test_cfg: OptConfigType = {},
    ) -> InstanceList:
        
        if test_cfg.get('flip_test', False):
            assert isinstance(feats, list) and len(feats) == 2
            flip_indices = batch_data_samples[0].metainfo['flip_indices']
            _feats, _feats_flip = feats

            _batch_pred_x, _batch_pred_y = self.forward(_feats)
            self.cim.eval_count_flip_indices = flip_indices
            try:
                _batch_pred_x_flip, _batch_pred_y_flip = self.forward(_feats_flip)
            finally:
                self.cim.eval_count_flip_indices = None
            _batch_pred_x_flip, _batch_pred_y_flip = flip_vectors(
                _batch_pred_x_flip, _batch_pred_y_flip,
                flip_indices=flip_indices)

            batch_pred_x = (_batch_pred_x + _batch_pred_x_flip) * 0.5
            batch_pred_y = (_batch_pred_y + _batch_pred_y_flip) * 0.5
        else:
            batch_pred_x, batch_pred_y = self.forward(feats)

        preds = self.decode((batch_pred_x, batch_pred_y))
        return preds

    @property
    def default_init_cfg(self):
        return [
            dict(type='Normal', layer=['Conv2d', 'Linear'], std=0.01, bias=0),
            dict(type='Constant', layer=['BatchNorm2d', 'BatchNorm1d'], val=1),
            dict(type='Normal', layer=['Embedding'], std=0.01)]

@HOOKS.register_module()
class CIMSelectionStatsHook(Hook):
    """Log validation joint-selection frequency (including flip-test passes).

    With flip_test=True each instance contributes two selections. Flipped-view
    joint IDs are remapped to original-image anatomical IDs before counting.
    """

    priority = 'LOW'

    def _cim(self, runner):
        model = runner.model.module if hasattr(runner.model, 'module') else runner.model
        return model.head.cim

    def before_val_epoch(self, runner):
        self._cim(runner).eval_selection_counts.zero_()

    def after_val_epoch(self, runner, metrics=None):
        counts = self._cim(runner).eval_selection_counts.detach().clone()
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            counts = counts.to(next(self._cim(runner).parameters()).device)
            torch.distributed.all_reduce(counts, op=torch.distributed.ReduceOp.SUM)
        rank, _ = get_dist_info()
        if rank == 0:
            counts_cpu = counts.cpu().tolist()
            total = sum(counts_cpu)
            fractions = [round(100.0 * n / total, 3) if total else 0.0
                         for n in counts_cpu]
            runner.logger.info(
                'CIM val selected-joint counts=%s ratios_percent=%s '
                '(both views counted when flip_test=True; IDs mapped to original frame)',
                counts_cpu, fractions)


@HOOKS.register_module()
class CIMRandomStateHook(Hook):
    """Equal fresh-run RNG after construction/loading; restore main-process RNG.

    DataLoader workers on a restarted process are recreated, so resumed random
    augmentations are not claimed to be bitwise identical to uninterrupted runs.
    """
    priority = 'LOW'

    def __init__(self, seed=21):
        self.seed = seed
        self.restored = None

    def after_load_checkpoint(self, runner, checkpoint):
        if runner._resume:
            self.restored = checkpoint.get('cim_rng_state')

    def before_train(self, runner):
        if self.restored is None:
            random.seed(self.seed)
            np.random.seed(self.seed)
            torch.manual_seed(self.seed)
            if torch.cuda.is_available(): torch.cuda.manual_seed_all(self.seed)
        else:
            random.setstate(self.restored['python'])
            np.random.set_state(self.restored['numpy'])
            torch.set_rng_state(self.restored['torch'].cpu())
            if torch.cuda.is_available() and self.restored.get('cuda') is not None:
                torch.cuda.set_rng_state_all([s.cpu() for s in self.restored['cuda']])

    def before_save_checkpoint(self, runner, checkpoint):
        checkpoint['cim_rng_state'] = dict(python=random.getstate(), numpy=np.random.get_state(),
            torch=torch.get_rng_state(), cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None)


@HOOKS.register_module()
class CIMResultsCSVHook(Hook):
    """Keep resumable independent validation + joint-frequency CSV files.

    Writes only on rank 0 after COCO validation. Re-running validation at an
    already-recorded epoch replaces that epoch's rows rather than duplicating
    them. CSVs are atomically replaced to avoid partially written files.
    """

    priority = 'LOW'

    _validation_columns = (
        'epoch', 'variant', 'timestamp_utc', 'AP', 'AP50', 'AP75',
        'APm', 'APl', 'AR', 'best_AP_so_far', 'best_epoch_so_far',
        'learning_rate', 'selection_total', 'val_loss_kpt', 'val_loss_cf', 'val_loss', 'metrics_json')
    _selection_columns = ('epoch', 'variant', 'joint_id', 'count',
                          'ratio', 'percentage', 'selection_total',
                          'flip_test_included')

    def __init__(self, variant='unknown'):
        self.variant = str(variant).lower()

    @staticmethod
    def _read_csv(path):
        if not path.exists():
            return []
        with path.open('r', newline='', encoding='utf-8') as handle:
            return list(csv.DictReader(handle))

    @staticmethod
    def _save_csv(path, columns, rows):
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp',
                                   dir=str(path.parent))
        try:
            with os.fdopen(fd, 'w', newline='', encoding='utf-8') as handle:
                writer = csv.DictWriter(handle, fieldnames=columns,
                                        extrasaction='ignore')
                writer.writeheader()
                writer.writerows(rows)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    @staticmethod
    def _as_float(value):
        if hasattr(value, 'item'):
            value = value.item()
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @classmethod
    def _metric(cls, metrics, *names):
        for name in names:
            if name in metrics:
                return cls._as_float(metrics[name])
        return None

    @staticmethod
    def _learning_rate(runner):
        try:
            values = runner.optim_wrapper.get_lr()
            if isinstance(values, dict):
                lr = values.get('lr')
                return float(lr[0]) if lr else ''
        except (AttributeError, TypeError, KeyError, IndexError):
            pass
        return ''

    def after_val_epoch(self, runner, metrics=None):
        rank, _ = get_dist_info()
        cim_model = runner.model.module if hasattr(runner.model, 'module') else runner.model
        counts_t = cim_model.head.cim.eval_selection_counts.detach().clone()
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            counts_t = counts_t.to(next(cim_model.parameters()).device)
            torch.distributed.all_reduce(counts_t, op=torch.distributed.ReduceOp.SUM)
        if rank != 0:
            return
        metrics = metrics or {}
        epoch = int(runner.epoch)
        output = Path(runner.work_dir)
        counts = counts_t.cpu().tolist()
        total = sum(counts)
        now = datetime.now(timezone.utc).isoformat(timespec='seconds')

        row = {
            'epoch': epoch,
            'variant': self.variant,
            'timestamp_utc': now,
            'AP': self._metric(metrics, 'coco/AP', 'AP'),
            'AP50': self._metric(metrics, 'coco/AP .5', 'coco/AP50', 'AP50'),
            'AP75': self._metric(metrics, 'coco/AP .75', 'coco/AP75', 'AP75'),
            'APm': self._metric(metrics, 'coco/AP (M)', 'coco/APm', 'APm'),
            'APl': self._metric(metrics, 'coco/AP (L)', 'coco/APl', 'APl'),
            'AR': self._metric(metrics, 'coco/AR', 'AR'),
            'learning_rate': self._learning_rate(runner),
            'selection_total': total,
            'val_loss_kpt': metrics.get('val_loss_kpt'),
            'val_loss_cf': metrics.get('val_loss_cf'),
            'val_loss': metrics.get('val_loss'),
            'metrics_json': json.dumps({str(k): self._as_float(v)
                                        for k, v in metrics.items()},
                                       ensure_ascii=False, sort_keys=True),
        }
        csv_file = output / 'validation_results.csv'
        previous = {int(r['epoch']): r for r in self._read_csv(csv_file)}
        previous[epoch] = row
        rows = [previous[e] for e in sorted(previous)]
        best = None
        best_epoch = None
        for record in rows:
            ap = self._as_float(record.get('AP'))
            if ap is not None and (best is None or ap > best):
                best, best_epoch = ap, int(record['epoch'])
            record['best_AP_so_far'] = best if best is not None else ''
            record['best_epoch_so_far'] = best_epoch if best_epoch is not None else ''
        self._save_csv(csv_file, self._validation_columns, rows)

        joint_file = output / 'joint_selection.csv'
        previous_joint = {(int(r['epoch']), int(r['joint_id'])): r
                          for r in self._read_csv(joint_file)}
        for joint_id, count in enumerate(counts):
            previous_joint[(epoch, joint_id)] = {
                'epoch': epoch,
                'variant': self.variant,
                'joint_id': joint_id,
                'count': count,
                'ratio': count / total if total else 0.0,
                'percentage': 100.0 * count / total if total else 0.0,
                'selection_total': total,
                'flip_test_included': bool(cim_model.test_cfg.get('flip_test', False)),
            }
        joint_rows = [previous_joint[k] for k in sorted(previous_joint)]
        self._save_csv(joint_file, self._selection_columns, joint_rows)
        runner.logger.info('CIM CSV written: %s, %s', csv_file, joint_file)


@HOOKS.register_module()
class CIMValidationLossHook(Hook):
    """FP32, unflipped EMA evaluation loss; no optimizer/RNG/BN updates.

    KLDiscretLoss sums over batch: accumulate its raw sum / total persons.
    Consistency loss averages over visible non-intervened joints: accumulate
    its numerator / total stable joints. Preserve original training reductions.
    """
    priority = 'ABOVE_NORMAL'

    def before_val_epoch(self, runner):
        self.kpt_sum = self.cf_sum = 0.0
        self.persons = self.stable = 0

    @torch.no_grad()
    def after_val_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        model = runner.model.module if hasattr(runner.model, 'module') else runner.model
        assert not model.training, 'Validation loss requires eval mode'
        cim = model.head.cim
        counts = cim.eval_selection_counts.clone()
        selected = cim.last_selected_indices
        try:
            with torch.autocast(device_type='cuda', enabled=False):
                data = model.data_preprocessor(data_batch, training=False)
                losses = model.loss(data['inputs'].float(), data['data_samples'])
                weights = torch.cat([d.gt_instance_labels.keypoint_weights
                                     for d in data['data_samples']], dim=0)
                mask = torch.nn.functional.one_hot(cim.last_selected_indices,
                                                    num_classes=17).bool()
                stable = int(((weights > 0) & ~mask).sum())
                kpt = float(losses['loss_kpt'])
                cf = float(losses['loss_cf'])
                if not np.isfinite(kpt + cf):
                    raise RuntimeError('Non-finite validation loss')
                self.kpt_sum += kpt
                self.cf_sum += cf * stable
                self.persons += len(data['data_samples'])
                self.stable += stable
        finally:
            cim.eval_selection_counts.copy_(counts)
            cim.last_selected_indices = selected

    def after_val_epoch(self, runner, metrics=None):
        if metrics is None or self.persons == 0:
            raise RuntimeError('Validation loss received no samples/metrics')
        kpt = self.kpt_sum / self.persons
        cf = self.cf_sum / self.stable if self.stable else 0.0
        metrics.update(val_loss_kpt=kpt, val_loss_cf=cf, val_loss=kpt+cf)
        runner.logger.info('val_loss=%.8f val_loss_kpt=%.8f val_loss_cf=%.8f '
                           '(unflipped FP32; persons=%d)', kpt+cf,kpt,cf,self.persons)
