"""Collect five independent experiment results into work_dirs/cim_comparison.csv."""
import argparse
import csv
import json
import re
from pathlib import Path

VARIANTS = ('baseline', 'a', 'b', 'c', 'd')
COLUMNS = ('variant', 'status', 'epochs_validated', 'best_epoch', 'best_AP',
           'last_epoch', 'last_AP', 'last_val_loss_kpt', 'last_val_loss_cf', 'last_val_loss', 'AP50_at_best', 'AP75_at_best',
           'APm_at_best', 'APl_at_best', 'AR_at_best', 'train_subset_sha256',
           'initial_checkpoint_sha256', 'best_checkpoint',
           'last_resume_checkpoint', 'total_active_seconds', 'total_active_hours',
           'total_active_hms', 'elapsed_including_pauses_hms', 'timing_status',
           'unconfirmed_interruption', 'experiment_dir')


def collect(work_dir, seed):
    data = []
    for variant in VARIANTS:
        directory = work_dir / f'cim_{variant}_amp128_seed{seed}'
        metadata_file = directory / 'run_metadata.json'
        results_file = directory / 'validation_results.csv'
        metadata = (json.loads(metadata_file.read_text(encoding='utf-8'))
                    if metadata_file.is_file() else {})
        if results_file.is_file():
            with results_file.open(newline='', encoding='utf-8') as handle:
                rows = list(csv.DictReader(handle))
        else:
            rows = []
        def numeric(row):
            try: return float(row['AP'])
            except (TypeError, ValueError, KeyError): return float('-inf')
        best = max(rows, key=numeric) if rows else {}
        last = max(rows, key=lambda x: int(x['epoch'])) if rows else {}
        saved_best = sorted(directory.glob('best*AP*.pth')) if directory.exists() else []
        saved_last = ((directory / 'last_checkpoint').read_text(encoding='utf-8').strip()
                      if (directory / 'last_checkpoint').exists() else '')
        last_epoch = int(last['epoch']) if last else 0
        max_epochs = int(metadata.get('max_epochs', 100))
        timer_file=directory/'training_time.json'
        timing=json.loads(timer_file.read_text()) if timer_file.exists() else {}
        checkpoint_path = Path(saved_last) if saved_last else None
        checkpoint_epoch = re.fullmatch(r'epoch_(\d+)\.pth', checkpoint_path.name) if checkpoint_path else None
        saved_complete = (checkpoint_path is not None and checkpoint_path.is_file()
                          and checkpoint_epoch is not None and int(checkpoint_epoch.group(1)) >= max_epochs)
        status = ('complete' if last_epoch >= max_epochs and saved_complete else
                  'in_progress' if directory.exists() and metadata else 'not_started')
        data.append(dict(
            variant=variant.upper(), status=status, epochs_validated=len(rows),
            best_epoch=best.get('epoch', ''), best_AP=best.get('AP', ''),
            last_epoch=last.get('epoch', ''), last_AP=last.get('AP', ''),
            last_val_loss_kpt=last.get('val_loss_kpt',''), last_val_loss_cf=last.get('val_loss_cf',''),
            last_val_loss=last.get('val_loss',''),
            AP50_at_best=best.get('AP50', ''), AP75_at_best=best.get('AP75', ''),
            APm_at_best=best.get('APm', ''), APl_at_best=best.get('APl', ''),
            AR_at_best=best.get('AR', ''),
            train_subset_sha256=metadata.get('train_annotation_sha256', ''),
            initial_checkpoint_sha256=metadata.get('initial_checkpoint_sha256', ''),
            best_checkpoint=str(saved_best[-1].resolve()) if saved_best else '',
            last_resume_checkpoint=saved_last,
            total_active_seconds=timing.get('total_active_seconds',''),
            total_active_hours=timing.get('total_active_hours',''),
            total_active_hms=timing.get('total_active_hms',''),
            elapsed_including_pauses_hms=timing.get('elapsed_including_pauses_hms',''),
            timing_status=timing.get('status',''),
            unconfirmed_interruption=timing.get('unconfirmed_interruption',''),
            experiment_dir=str(directory.resolve()),
        ))
    return data


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--work-dir', type=Path, default=None)
    p.add_argument('--seed', type=int, default=21)
    args = p.parse_args()
    root = Path(__file__).resolve().parents[2]
    work_dir = (args.work_dir or (root / 'work_dirs')).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    output = work_dir / 'cim_comparison.csv'
    with output.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(collect(work_dir, args.seed))
    print('Comparison CSV:', output)


if __name__ == '__main__':
    main()
