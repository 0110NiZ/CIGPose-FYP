"""Single-GPU fixed-protocol launcher. Run from any directory."""
import argparse
import fcntl
import hashlib
import json
import os
import platform
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
os.environ.setdefault('TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD', '1')
sys.path.insert(0, str(ROOT / 'mmpose'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
VARIANTS = {'BASELINE': ('confidence', False, False),
            'A': ('learnable', False, False), 'B': ('learnable', True, False),
            'C': ('learnable', False, True), 'D': ('learnable', True, True)}

def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4*1024*1024), b''): h.update(block)
    return h.hexdigest()

def verify_package():
    manifest_path = ROOT / 'PACKAGE_MANIFEST.json'
    manifest = json.loads(manifest_path.read_text())
    for name, digest in manifest['sha256'].items():
        path = ROOT / name
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError('Package file changed/missing: ' + name + '. Re-extract the shared package; do not mix experiments.')
    return sha256(manifest_path)

def configure(coco_root, variant):
    from mmengine.config import Config
    import torch
    coco_root = Path(coco_root).expanduser().resolve()
    os.environ['CIG_COCO_ROOT'] = str(coco_root)
    os.environ['CIM_VARIANT'] = variant
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    os.chdir(ROOT / 'mmpose')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    cfg = Config.fromfile(str(ROOT/'lightweight/configs/team128_baseline100.py'))
    mode, neighbor, global_context = VARIANTS[variant]
    cfg.model.head.cim_cfg.update(selection_mode=mode, use_neighbor=neighbor, use_global=global_context)
    cfg.experiment_variant = variant
    for h in cfg.custom_hooks:
        if h['type'] == 'CIMResultsCSVHook': h['variant'] = variant
    cfg.custom_hooks.append(dict(type='CIMRandomStateHook', seed=21))
    return cfg

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('variant', type=str.upper, choices=list(VARIANTS))
    parser.add_argument('--coco-root', required=True, help='Folder containing train2017/ and val2017/ (images only).')
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--verify-images', action='store_true', help='Verify every required image SHA256 (also done by --check-only).')
    args = parser.parse_args()
    print('Checking release file hashes...', flush=True)
    package_hash = verify_package()
    print('Release hashes PASS. Loading fixed configuration...', flush=True)
    cfg = configure(args.coco_root, args.variant)
    import torch, mmengine, mmcv, mmdet, mmpose, numpy, albumentations, torchvision
    from mmengine.runner import Runner
    from mmpose.utils import register_all_modules
    from cim_run_state import prepare
    register_all_modules()
    image_root = Path(args.coco_root).expanduser().resolve()
    for split, ann in [('train2017','person_keypoints_train2017_stratified30_seed21.json'),
                       ('val2017','person_keypoints_val2017.json')]:
        images = json.loads((ROOT/'lightweight/data'/ann).read_text())['images']
        folder = image_root / split
        print('Checking images:', folder, flush=True)
        # COCO filenames are flat: scan once instead of resolving symlink roots
        # and making a filesystem round-trip per image on WSL/network mounts.
        available = {entry.name for entry in os.scandir(folder) if entry.is_file()}
        missing=[im['file_name'] for im in images if im['file_name'] not in available]
        if missing: raise FileNotFoundError('%s: %d missing images, e.g. %s' % (split,len(missing),missing[:3]))
        print(split, len(images), 'required images PASS', flush=True)
    if args.check_only or args.verify_images:
        expected=json.loads((ROOT/'lightweight/data/image_manifest.json').read_text())['images']
        for n,(rel,record) in enumerate(expected.items(),1):
            image_file=image_root/rel
            if image_file.stat().st_size != record['bytes'] or sha256(image_file) != record['sha256']:
                raise RuntimeError('Image content differs from shared dataset: '+rel)
            if n%2000==0: print('Image content verified',n,'/',len(expected),flush=True)
        print('All required image bytes match the shared dataset.',flush=True)
    if not torch.cuda.is_available(): raise RuntimeError('Formal training requires one CUDA GPU.')
    if int(os.environ.get('WORLD_SIZE', '1')) != 1: raise RuntimeError('Use one process / one GPU; distributed launch changes this protocol.')
    environment = dict(python=platform.python_version(), torch=torch.__version__, mmengine=mmengine.__version__,
                       mmcv=mmcv.__version__, mmdet=mmdet.__version__, mmpose=mmpose.__version__,
                       numpy=numpy.__version__, albumentations=albumentations.__version__, torchvision=torchvision.__version__,
                       gpu=torch.cuda.get_device_name(0), cuda=torch.version.cuda, cudnn=torch.backends.cudnn.version(),
                       training_precision="fp16_amp", validation_precision="fp32", tf32_matmul=False, tf32_cudnn=True, deterministic=True)
    normalized = cfg.pretty_text.replace(str(ROOT), '<PACKAGE>').replace(str(Path(args.coco_root).expanduser().resolve()), '<COCO>')
    protocol = dict(package_sha256=package_hash,
                    resolved_config_sha256=hashlib.sha256(normalized.encode()).hexdigest(), environment=environment)
    if args.check_only:
        print(json.dumps(dict(status='PASS',variant=args.variant,protocol=protocol),indent=2)); return
    run_dir=ROOT/'work_dirs'/('cim_%s_amp128_seed21'%args.variant.lower())
    run_dir.parent.mkdir(exist_ok=True)
    lock=(run_dir.parent/'cim_experiments.lock').open('w')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    mode, checkpoint=prepare(run_dir,ROOT,args.variant,ROOT/'lightweight/weights/shared_init_seed21.pth',
                              ROOT/'lightweight/data/person_keypoints_train2017_stratified30_seed21.json',100,21,protocol=protocol)
    if mode=='complete':
        print('Already complete:',run_dir); return
    cfg.work_dir=str(run_dir); cfg.load_from=str(checkpoint); cfg.resume=mode=='resume'; cfg.launcher='none'
    print('MODE',mode,'VARIANT',args.variant,'CHECKPOINT',checkpoint,flush=True)
    print(json.dumps(environment),flush=True)
    from training_timer import TrainingTimer
    timer=TrainingTimer(run_dir).start()
    status='failed'
    try:
        runner=Runner.from_cfg(cfg)
        runner.train()
        status='complete'
    except KeyboardInterrupt:
        status='interrupted'
        raise
    finally:
        timer.stop(status)
    from collect_cim_results import main as collect_main
    sys.argv=[sys.argv[0],'--work-dir',str(ROOT/'work_dirs')]
    collect_main()

if __name__=='__main__': main()
