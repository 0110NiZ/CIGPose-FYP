# Portable shared team128 config; launcher selects BASELINE/A/B/C/D.
_base_ = ['./small30_cim_amp128.py']
model = dict(head=dict(cim_cfg=dict(selection_mode='confidence')))
