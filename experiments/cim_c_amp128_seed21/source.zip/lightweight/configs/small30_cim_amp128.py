import os

"""Five-way CIM ablation on top of the existing 30%-COCO small Head256.

A (default): False,False; B: True,False; C: False,True; D: True,True.
Confidence baseline: change selection_mode to 'confidence'.
Run with lightweight/scripts/train_cim_variant.sh [baseline|A|B|C|D].
"""
_base_ = ['./base_small30.py']

# The base config already defines the SAME 30% split (44,941 instances),
# model, augmentations, 100-epoch schedule, validation and seed 21.
model = dict(head=dict(cim_cfg=dict(
    selection_mode='learnable',
    use_neighbor=False,
    use_global=False,
    scorer_hidden_dim=32,
    selection_tau=1.0,
)))

# Match GitHub team128: training AMP (FP16), validation FP32, no accumulation.
optim_wrapper = dict(_delete_=True, type='AmpOptimWrapper', loss_scale='dynamic',
    dtype='float16', accumulative_counts=1,
    optimizer=dict(type='AdamW', lr=0.001/3, weight_decay=0.05),
    paramwise_cfg=dict(norm_decay_mult=0, bias_decay_mult=0, bypass_duplicate=True),
    clip_grad=dict(max_norm=35, norm_type=2))
auto_scale_lr = dict(enable=False, base_batch_size=128)
val_cfg = dict(type='ValLoop', fp16=False)
test_cfg = dict(type='TestLoop', fp16=False)

# Optional: point this at a common initial checkpoint made with
# lightweight/scripts/make_cim_initial_checkpoint.py, for *exactly* the
# same public-layer initial weights across the original and all 4 variants.
load_from = None
resume = False

# Save full checkpoints every 10 epochs, plus the best AP checkpoint.
default_hooks = dict(checkpoint=dict(
    interval=10,
    max_keep_ckpts=1,
    save_last=True,
    save_optimizer=True,
    save_param_scheduler=True,
    save_best='coco/AP',
    rule='greater',
))

# Each validation writes per-run validation_results.csv and joint_selection.csv.
# The launcher sets experiment_variant; config may also be invoked directly.
experiment_variant = os.environ.get('CIM_VARIANT', 'A').upper()

# Extend rather than replace the original EMA and stage-2 pipeline hooks.
# This logs selected joint frequencies at every validation, including flips.
custom_hooks = _base_.custom_hooks + [
    dict(type='CIMValidationLossHook'),
    dict(type='CIMSelectionStatsHook'),
    dict(type='CIMResultsCSVHook', variant=experiment_variant),
]

# Generate supervision in validation coordinates, without random augmentation.
val_dataloader = dict(dataset=dict(pipeline=[
    dict(type='LoadImage', backend_args=dict(backend='local')),
    dict(type='GetBBoxCenterScale'),
    dict(type='TopdownAffine', input_size=(192, 256)),
    dict(type='GenerateTarget', encoder=_base_.codec),
    dict(type='PackPoseInputs'),
]))
